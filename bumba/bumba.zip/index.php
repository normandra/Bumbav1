<?php require_once('config/setup.php');?>
<!DOCTYPE html>
<html>
	<head>
		<title>Bumba</title>
		<?php include('templates/header.php');?>
	</head>
	
	<body>
		<div class="container">
			
			<?php
            $query = "SELECT * FROM user_post ORDER BY id DESC";
            $statement = $db->query($query);
					
            while($r = $statement->fetch()) {
                $title = $r['title'];
                $body = $r['body'];
                $id = $r['id'];
				$time = $r['time'];
                $short_body = substr(strip_tags($body), 0, 200);
				echo '<div class="box">';
                echo sprintf('<a class="mainlink" href="post.php?id=%s">%s.%s</a>',$id,$id, $title);
                echo sprintf('  %s<p>%s...</p>',$time,$short_body);
				echo '</div>';
            }
        ?>
			
			
		</div>
		<?php include('../bumba/templates/footer.php');?>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
		<script src="js/bootstrap.js"></script>
	</body>
</html>