<?php
	header("Location: ../bumba/index.php");
?>