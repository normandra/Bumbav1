<!-- <div class="footer navbar navbar-inverse navbar-fixed-bottom">
	<div class = "container">
		<p class = "navbar-text">Site is under construction!</p>
	</div>	
</div>

-->